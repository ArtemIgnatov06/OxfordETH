from chain.chain_fxrp import fxrp_client

print(fxrp_client.contract.events.Transfer())
